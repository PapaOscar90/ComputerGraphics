#ifndef TEXTURE_H
#define TEXTURE_H

#include "image.h"

typedef Image Texture;
struct TextureCoordinates {
  double u, v;
};

#endif /* TEXTURE_H */
